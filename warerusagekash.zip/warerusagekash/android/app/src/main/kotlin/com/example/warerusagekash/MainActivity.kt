package com.example.warerusagekash

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
