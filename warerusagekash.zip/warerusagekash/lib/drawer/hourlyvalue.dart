import 'package:flutter/material.dart';

import 'package:charts_flutter/flutter.dart' as charts;
import 'package:warerusagekash/models/daily_usage_model.dart';


class DailyUsage extends StatelessWidget {
  final List<DailyUsageModel> data;
  final String totalValueConsumed,
      H0,H1,H2,H3,H4,H5,H6,H7,H8,H9,H10,H11,H12,H13,H14,H15,H16,H17,H18,H19,H20,H21,H22,H23,flowrate;
  DailyUsage({Key key, this.data, this.totalValueConsumed,this.H0,
    this.H1,this.H2, this.H3,this.H4, this.H5, this.H6,this.H7,
    this.H8,this.H9, this.H10,this.H11,this.H12
    ,this.H13, this.H14, this.H15, this.H16,this.H17, this.H18, this.H19,
    this.H20, this.H21, this.H22, this.H23,this.flowrate

  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    List<charts.Series<DailyUsageModel,String>> series = [
      charts.Series(
          id: "Usage",
          data: data,
          domainFn: (DailyUsageModel model,_)=> model.hours,
          measureFn: (DailyUsageModel model,_) => model.usageValue,
          colorFn: (DailyUsageModel model,_) => model.color
      )
    ];
    return SafeArea(
        child: Scaffold(appBar: AppBar(title: Text("Hourly Values"),),
          body: SingleChildScrollView(
    child: Column(
    children:[
      Text('Flow rate $flowrate',style: TextStyle(fontSize: 20,fontWeight:FontWeight.bold)),
    Text('Total water consumed $totalValueConsumed',style: TextStyle(fontSize: 20,fontWeight:FontWeight.bold)),
    Text('H0 $H0',style: TextStyle(fontSize: 20,fontWeight:FontWeight.bold)),
    Text('H1 $H1',style: TextStyle(fontSize: 20,fontWeight:FontWeight.bold)),
    Text('H2 $H2',style: TextStyle(fontSize: 20,fontWeight:FontWeight.bold)),
    Text('H3 $H3',style: TextStyle(fontSize: 20,fontWeight:FontWeight.bold)),
    Text('H4 $H4',style: TextStyle(fontSize: 20,fontWeight:FontWeight.bold)),
    Text('H5 $H5',style: TextStyle(fontSize: 20,fontWeight:FontWeight.bold)),
    Text('H6 $H7',style: TextStyle(fontSize: 20,fontWeight:FontWeight.bold)),
    Text('H8 $H8',style: TextStyle(fontSize: 20,fontWeight:FontWeight.bold)),
    Text('H9 $H9',style: TextStyle(fontSize: 20,fontWeight:FontWeight.bold)),
    Text('H10 $H10',style: TextStyle(fontSize: 20,fontWeight:FontWeight.bold)),
    Text('H11 $H11',style: TextStyle(fontSize: 20,fontWeight:FontWeight.bold)),
    Text('H12 $H12',style: TextStyle(fontSize: 20,fontWeight:FontWeight.bold)),
    Text('H13 $H13',style: TextStyle(fontSize: 20,fontWeight:FontWeight.bold)),
    Text('H014 $H14',style: TextStyle(fontSize: 20,fontWeight:FontWeight.bold)),
    Text('H15 $H15',style: TextStyle(fontSize: 20,fontWeight:FontWeight.bold)),
    Text('H16 $H16',style: TextStyle(fontSize: 20,fontWeight:FontWeight.bold)),
    Text('H17 $H17',style: TextStyle(fontSize: 20,fontWeight:FontWeight.bold)),
    Text('H18 $H18',style: TextStyle(fontSize: 20,fontWeight:FontWeight.bold)),
    Text('H19 $H19',style: TextStyle(fontSize: 20,fontWeight:FontWeight.bold)),
    Text('H20 $H20',style: TextStyle(fontSize: 20,fontWeight:FontWeight.bold)),
    Text('H21 $H21',style: TextStyle(fontSize: 20,fontWeight:FontWeight.bold)),
    Text('H22 $H22',style: TextStyle(fontSize: 20,fontWeight:FontWeight.bold)),
    Text('H23 $H23',style: TextStyle(fontSize: 20,fontWeight:FontWeight.bold)),









    ]   ),
    ),

        )
    );
  }
}