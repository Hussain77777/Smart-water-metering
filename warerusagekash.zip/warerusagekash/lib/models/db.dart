


class Posts{
// ignore: non_constant_identifier_names
//String  Email,Address;
// ignore: non_constant_identifier_names
  String Email,Address;
  Posts (this. Email,this.Address,) ;
}