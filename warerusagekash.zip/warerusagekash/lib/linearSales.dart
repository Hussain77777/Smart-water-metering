class LinearSales {
  final int year;
  final int sales;

  LinearSales(this.year, this.sales);
}
