import 'dart:async';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../linearSales.dart';



class Graph extends StatefulWidget {
  @override
  _GraphState createState() => _GraphState();
}

class _GraphState extends State<Graph> {
  String uid = FirebaseAuth.instance.currentUser.uid;

  Map<dynamic, dynamic> data;
  List<Map<String, dynamic>> listMap = [];
  int a = 0, b = 0, reslut=0;
  int flowMainline, flowRoom1, flowRoom1Result=0, flowMainlineResult=0;
  LinearSales linearSales;
  List<LinearSales> listLinearSales = [];
  String userName, address, flatno, mobileNumber, email, pin;

  int intValue;
  setIntValues(int value, String name) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setInt(name, value);
  }

  int room1Flow, mainlineFlow;
  int room1Water, mainlineWater, room1WaterReslut=0, mainlineWaterReslut=0;

  getIntValuesSF() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      room1Flow = prefs.getInt("room1Flow");
      mainlineFlow = prefs.getInt("mainlineFlow");
      intValue = prefs.getInt('dailyWaterConsumed');
      room1Water = prefs.getInt("room1Water");

      mainlineWater = prefs.getInt('mainlineWater');
    });
  }

  int sum=0;
  int monthly = 0;
  void addMonthlyValue() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    Timer(Duration(hours: 24), () {
      if (monthly != null) {
        setState(() {
          monthly = sum;
          print(monthly);
        });
        setIntValues(monthly, "monthly");
        monthly = prefs.getInt("monthly");
      } else {
        setState(() {
          monthly = sum;
        });
      }
    });
  }

  void removeDailyUsage() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    Timer(Duration(seconds: 10), () {
      prefs.remove('dailyWaterConsumed');
    });
  }

  @override
  void initState() {
    getIntValuesSF();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    addMonthlyValue();
    getIntValuesSF();

    return Scaffold(
      body: StreamBuilder(
        stream: FirebaseDatabase.instance
            .reference()
            .child("usersdata")
            .child(uid)
            .onValue,
        builder: (ctx, snapShot) {
          if (snapShot.hasData) {
            getIntValuesSF();
            data = Map<String, dynamic>.from(snapShot.data.snapshot.value);
            if (data != null) {
              data.forEach((key, value) {
                getIntValuesSF();

                value.forEach((key, d) {
                  if (key == "Name") {
                    userName = d;
                  }
                  if (key == "Email") {
                    email = d;
                  }
                  if (key == "Address") {
                    address = d;
                  }
                  if (key == "Mobile No") {
                    mobileNumber = d;
                  }
                  if (key == "flat no") {
                    flatno = d;
                  }

                  // email = d["Email"];

                  if (key == "Flat Data") {
                    d.forEach((key, c) {
                      getIntValuesSF();


                      if (key == "Room1") {
                        b = c["Total Water Consumed"];
                        flowRoom1 = c["Current Flow Rate"];

                        if (room1Flow == null) {
                          setIntValues(flowRoom1, "room1Flow");
                        }
                        if (room1Water == null) {
                          setIntValues(b, "room1Water");
                        }
                        getIntValuesSF();
                         
                        if (room1Water != null) {
                          room1WaterReslut = room1Water + b;
                        }
                        if (room1Flow != null) {
                          flowRoom1Result = room1Flow + flowRoom1;
                        }
                      }
                      if (key == "Mainline") {
                        a = c["Total Water Consumed"];
                        reslut = a + b;
                        if (intValue == null) {
                          setIntValues(reslut, "dailyWaterConsumed");
                          getIntValuesSF();
                        }
                        if (mainlineWater == null) {
                          setIntValues(a, "mainlineWater");
                        }
                        getIntValuesSF();
                        if (mainlineWater != null) {
                          mainlineWaterReslut = mainlineWater + a;
                        }
                        if (intValue != null) {
                          sum = intValue + reslut;
                        }

                        getIntValuesSF();

                        flowMainline = c["Current Flow Rate"];
                        if (mainlineFlow == null) {
                          setIntValues(flowMainline, "mainlineFlow");
                        }
                        if (mainlineFlow != null) {
                          flowMainlineResult = mainlineFlow + flowMainline;
                        }
                      }
                    });
                  }
                });
              });
            }
            return ListView(
              children: [
                SizedBox(
                  height: 12.0,
                ),
                Center(child: Text("User Details")),
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SizedBox(
                      height: 12.0,
                    ),
                    Text("UserName : $userName"),
                    SizedBox(
                      height: 12.0,
                    ),
                    Text("Email : $email"),
                    SizedBox(
                      height: 12.0,
                    ),
                    Text("Address : $address"),
                    SizedBox(
                      height: 12.0,
                    ),
                    Text("Mobile Number  : $mobileNumber"),
                    SizedBox(
                      height: 12.0,
                    ),
                    Text("Flat No : $flatno"),
                  ],
                ),
                SizedBox(
                  height: 36.0,
                ),
              //  DailyGraph(listLinearSales),
                SizedBox(
                  height: 12.0,
                ),

                Center(child: Text("Monthly Usage = $monthly")),

                // Center(child: Text("Current Flow Rate Mainline = $a")),
                Center(child: Text("Total Water Consumed Total = $sum")),
                Center(
                    child: Text(
                        "Total Water Consumed Mainline = $mainlineWaterReslut")),
                Center(
                    child:
                    Text("Total Water Consumed Room1 = $room1WaterReslut")),

                SizedBox(
                  height: 36.0,
                ),
                //MonthlyGraph(reslut),
                Center(
                    child: Text("Current Flow Rate Room1 = $flowRoom1Result")),
                Center(
                    child: Text(
                        "Current Flow Rate Mainline= $flowMainlineResult")),

                SizedBox(
                  height: 36.0,
                ),
              ],
            );
          } else {
            return Center(
              child: CircularProgressIndicator(),
            );
          }
        },
      ),
    );
  }
}
